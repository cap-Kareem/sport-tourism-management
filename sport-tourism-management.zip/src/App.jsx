import { useState } from 'react';

export default function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-gray-900 transition-colors">
        <header className="w-full text-center py-6 bg-gradient-to-r from-blue-500 to-green-400 dark:from-blue-700 dark:to-green-600 text-white shadow-lg">
          <h1 className="text-3xl font-bold">🎓 برنامج إدارة السياحة الرياضية</h1>
          <p className="text-sm opacity-90">كل ما تحتاجه من ملخصات واختبارات وتدريبات في مكان واحد</p>
        </header>
        <main className="flex flex-col items-center mt-10 space-y-6">
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="px-4 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white dark:bg-gray-700 dark:hover:bg-gray-600"
          >
            {darkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
          </button>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-10/12">
            {[1,2,3,4].map((year) => (
              <div key={year} className="bg-gradient-to-r from-yellow-300 to-orange-400 dark:from-yellow-600 dark:to-orange-500 p-6 rounded-2xl shadow-md hover:scale-105 transition-transform">
                <h2 className="text-2xl font-semibold mb-2 text-white">الفرقة {year}</h2>
                <p className="text-white opacity-90">اضغط لعرض المقررات الدراسية والملخصات</p>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
